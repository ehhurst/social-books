import '../assets/css/AppFooter.css';
import '../assets/css/global.css';
import NavBar from './NavBar';
function AppFooter() {
    return (<footer>
            <NavBar />
        </footer>);
}
export default AppFooter;
