

function PageNotFound() {
    return(
        <main>
            <div>
                <h3>Oops! We couldn't find the page you were looking for. </h3>
            </div>
        </main>
    );
};

export default PageNotFound;