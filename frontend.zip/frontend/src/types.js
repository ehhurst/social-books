export const categories = [
    "Fiction",
    "Poetry",
    "Fantasy",
    "History",
    "Science fiction",
    "Programming"
];
